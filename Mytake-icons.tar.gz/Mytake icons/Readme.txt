"Mytake" icons are simple edits to selective Papirus icons and are in no way official.
I may add / update more in the future.

To use:
Backup the Papirus original icons first then open Papirus icon folder as root an copy the "Mytake" icons to the following locations overwriting the originals.

Icon locations:

user-trash.svg
user-trash-full.svg

To directory:
/usr/share/icons/Papirus/64x64/places (plus 22x22/24x24/32x32/48x48)


computer-laptop.svg
computer.svg

To directory:
/usr/share/icons/Papirus/64x64/devices (plus 22x22/24x24/32x32/48x48)

Credits:
Created originally by the Papirus Development Team 
https://github.com/PapirusDevelopmentTeam

Based upon the Papirus icon theme
https://github.com/PapirusDevelopmentTeam/papirus-icon-theme

License:
The license for "Mytake" icons are exactly the same as the original Papirus icons - GPL-3.0 license.
